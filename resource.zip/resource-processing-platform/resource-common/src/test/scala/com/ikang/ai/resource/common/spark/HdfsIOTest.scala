package com.ikang.ai.resource.common.spark

import java.io.File

import com.ikang.ai.resource.analysis.PersonMeta
import org.scalatest.FunSuite
import com.ikang.ai.resource.common.spark.HdfsIO._
import org.apache.spark.{SparkConf, SparkContext}


class HdfsIOTest extends FunSuite {
  test("save as parquet file") {
    val conf: SparkConf = new SparkConf()
      .setAppName(this.getClass.getSimpleName)
      .setIfMissing("spark.master", "local")
      .setIfMissing("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    val sc = new SparkContext(conf)
    val hank = new PersonMeta()
    hank.age = 30
    hank.area = "西安"
    hank.name = "hank"
    hank.weight = 67.5
    val james = new PersonMeta()
    james.age = 25
    james.area = "北京"
    james.name = "james"
    james.weight = 60
    val personRdd = sc.parallelize(Array(hank, james))
    val directory = new File("/tmp/parquet/person")
    if (!directory.exists()) {
      personRdd.saveAsParquetFile("/tmp/parquet/person")
    }
    sc.stop()
  }

  test("read from parquet file") {
    val conf: SparkConf = new SparkConf()
      .setAppName(this.getClass.getSimpleName)
      .setIfMissing("spark.master", "local")
      .setIfMissing("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
    val sc = new SparkContext(conf)
    val personRdd = sc.thriftParquetFile("/tmp/parquet/person", classOf[PersonMeta])
    personRdd.foreach(println)
    sc.stop
  }
}
