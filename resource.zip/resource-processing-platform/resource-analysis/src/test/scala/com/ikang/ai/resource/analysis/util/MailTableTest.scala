package com.ikang.ai.resource.analysis.util

import org.scalatest.FunSuite

class MailTableTest extends FunSuite {

  test("testSendMail") {
    val nameContent = MailTable.getGeneralTable("1.人员统计",
      List("姓名", "年龄", "性别"),
      List(List("andy", "12", "男"), List("bob", "12", "男"), List("james", "12", "男")))
    val peopleContent = MailTable.getGeneralTable("2.人口统计",
      List("国家", "城市", "人口"),
      List(List("中国", "北京", "2100"), List("中国", "深圳", "1200")))
    val areaContent = MailTable.getGeneralTable("3.面积统计",
      List("国家", "面积"),
      List(List("中国", "960"), List("美国", "960")))
//    MailTable.sendMail("统计测试", MailTable.getGeneralTableStyle + nameContent + peopleContent + areaContent,
//      Array("songling.gao@ikang.com"), Array("zhicheng.ma@ikang.com", "teng.zuo@ikang.com"))
  }

}
