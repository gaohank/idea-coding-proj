package com.ikang.ai.resource.analysis.util

import org.apache.commons.mail.{DefaultAuthenticator, HtmlEmail}

object MailTable {
  private val generalTableStyle =
    """
      |<style type="text/css">
      | table.gridtable {
      |	  font-family: verdana,arial,sans-serif;
      |	  font-size:11px;
      |	  color:#292929;
      |   border-width: 1px;
      |   border-color: #333333;
      |   border-collapse: collapse;
      |   width:600px;
      | }
      |	table.gridtable th {
      |   border-width: 1px;
      |	  padding: 8px;
      |	  border-style: solid;
      |	  border-color: #666666;
      |	  background-color: #87CEEB;
      |	}
      |	table.gridtable td {
      |   border-width: 1px;
      |   padding: 8px;
      |   border-style: solid;
      |   border-color: #666666;
      |   background-color: #F0FFFF;
      | }
      |</style>
    """.stripMargin

  def getGeneralTableStyle: String = generalTableStyle

  def getGeneralTable(title: String, header: List[String], rows: List[List[String]]): String = {
    val titleStr  = s"<b>$title</b>"
    val headerStr = s"<tr>${header.map(l => s"<th>$l</th>").mkString}</tr>"
    val rowsStr =
      rows.map(row => s"<tr>${row.map(cell => s"<td>$cell</td>").mkString}</tr>").mkString
    s"""
       |<p />
       |$titleStr
       |<table class="gridtable">
       |$headerStr
       |$rowsStr
       |</table>
       |""".stripMargin
  }

  /**
    * 发送邮件
    * @param title 邮件标题
    * @param html 邮件内容
    * @param to 收件人
    * @param cc 抄送
    * @return 无
    */
  def sendMail(title: String,
               html: String,
               to: Array[String],
               cc: Array[String] = Array.empty[String]): String = {
    val email = new HtmlEmail
    email.setHostName("smtp.ikang.com")
    email.setAuthenticator(new DefaultAuthenticator("zhicheng.ma@ikang.com", "Aa123456!"))
    email.setFrom("zhicheng.ma@ikang.com", "爱康大数据AI中心邮件助手", "UTF-8")
    email.setSubject(title)
    to.foreach(email.addTo)
    cc.foreach(email.addCc)
    email.setCharset("UTF-8")
    email.setHtmlMsg(html)
    email.send()
  }
}
