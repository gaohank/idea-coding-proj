package com.ikang.ai.resource.analysis.mail

object ForTest {
  def main(args: Array[String]): Unit = {
    print("1234")
  }
}
