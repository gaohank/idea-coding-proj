package com.ikang.ai.resource.analysis.dashboard

import com.ikang.ai.resource.analysis.util.MailTable
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.types.StructType

case class Info(
                 orgid: String,
                 id: Long,
                 workno: String,
                 checkitemsid: Long,
                 itemindexmiscode: String,
                 itemindexname: String,
                 itemindexresulttype: Double,
                 itemindexinceptcoding: String,
                 itemindexresultunit: String,
                 itemindexresulttempletmiscode: String,
                 isexeception: String,
                 itemindexresultvalue: String,
                 normallowvalue: String,
                 normalhighvalue: String,
                 itemindexshowindex: Long,
                 examitemid: Long,
                 scrq: String,
                 regdate: String,
                 cardid: String
)

object DauStatistics {
  def main(args: Array[String]): Unit = {
    require(args.length == 1, "need input")
    val Array(input) = args
    val conf = new SparkConf().setAppName("DauStatistics").setIfMissing("spark.master", "local")
    val spark = SparkSession.builder().config(conf).getOrCreate()
    val infoDF = spark.read.format("csv")
      .schema(ScalaReflection.schemaFor[Info].dataType.asInstanceOf[StructType])
      .load(input)
    infoDF.createOrReplaceTempView("info")
    var content: List[List[String]] = List()
    spark.sqlContext.sql("select substring_index(scrq, ' ', 1) as date, count(distinct workno) as num from info group by date")
      .sort("date")
      .collect()
      .foreach(row => content = content ::: List(List(row.getAs[String]("date"), row.getAs("num").toString)))
    val totalContent = MailTable.getGeneralTable("1.周内日活", List("日期", "体检人数"), content)
    MailTable.sendMail("统计日活", MailTable.getGeneralTableStyle + totalContent,
      Array("songling.gao@ikang.com"), Array("zhicheng.ma@ikang.com", "teng.zuo@ikang.com"))
  }
}
