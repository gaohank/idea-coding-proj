namespace java com.ikang.ai.resource.flow

struct HealthData {
    1:optional string workNo;
    2:optional string scrq; // 生成日期
    3:optional string examUser; // 体检人姓名
    4:optional string examUserSex; // 体检人性别
    5:optional string examUserBirth; // 体检人生日
    6:optional string checkItemMisCode; // 项目MIS码
    7:optional string familiarDiagnoseMisCode; // 诊断MIS码
    8:optional string familiarDiagnoseName; // 诊断名称
    9:optional string itemIndexMisCode; // 指标MIS码
    10:optional string content; // 诊断描述
}