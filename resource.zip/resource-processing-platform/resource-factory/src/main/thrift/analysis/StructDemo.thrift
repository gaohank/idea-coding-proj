namespace java com.ikang.ai.resource.analysis

struct PersonMeta {
    1:optional string name;
    2:optional string area;
    3:optional i32 age;
    4:optional double weight;
    5:optional i64 timestamp;
    6:optional list<string> friends;
}