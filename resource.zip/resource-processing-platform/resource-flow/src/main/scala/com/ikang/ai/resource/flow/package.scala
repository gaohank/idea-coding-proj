package com.ikang.ai.resource

import com.ikang.ai.resource.flow.transformer.Transformer
import com.typesafe.config.ConfigFactory
import org.slf4j.LoggerFactory

import scala.collection.JavaConversions._

package object flow {
  private val logger = LoggerFactory.getLogger("package-flow")
  private val transformerPath = "com.ikang.ai.resource.flow.transformer"

  def getTransformers[T](fileName: String, path: String = transformerPath): List[Transformer[T]] = {
    ConfigFactory.load(fileName)
      .getStringList(path)
      .map { t =>
        Class.forName(t).newInstance().asInstanceOf[Transformer[T]]
      }.toList
  }

  def runTransformers[T](data: T, transformers: List[Transformer[T]]): Option[T] = {
    transformers.foldLeft(Option(data)) {
      case (Some(v), transformer: Transformer[T]) =>
        val transData = transformer.transform(v)
        if (!transformer.check(transData.get))
          logger.error(s"${transformer.getClass} transformer failed")
        transData
      case (None, _: Transformer[T]) => None
    }
  }
}
