package com.ikang.ai.resource.flow.business.health

import com.ikang.ai.resource.flow.{HealthData, getTransformers, runTransformers}
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.catalyst.ScalaReflection
import org.apache.spark.sql.types.StructType
import org.json4s.jackson.Serialization
import org.json4s.jackson.Serialization.write
import org.json4s.{Formats, NoTypeHints}

object HealthNorm {
  implicit val formats: AnyRef with Formats = Serialization.formats(NoTypeHints)

  def main(args: Array[String]): Unit = {
    require(args.length == 2, "need input, output")
    val Array(input, output) = args
    val conf = new SparkConf().setAppName(this.getClass.getSimpleName).setIfMissing("spark.master", "local")
    val spark = SparkSession.builder().config(conf).getOrCreate()
    val healthDF = spark.read.format("csv").schema(ScalaReflection.schemaFor[HealthInfo].dataType.asInstanceOf[StructType]).load(input)

    val transformers = getTransformers[HealthData]("transformer/health-transformer.conf")

    import spark.sqlContext.implicits._
    val healthRdd =
      healthDF.as[HealthInfo]
        .rdd
        .map {v =>
          val data = new HealthData()
          data.setWorkNo(Option(v.workNo).getOrElse(""))
          data.setScrq(Option(v.scrq).getOrElse(""))
          data.setExamUser(Option(v.examUser).getOrElse(""))
          data.setExamUserSex(Option(v.examUserSex).getOrElse(""))
          data.setExamUserBirth(Option(v.examUserBirth).getOrElse(""))
          data.setCheckItemMisCode(Option(v.checkItemMisCode).getOrElse(""))
          data.setFamiliarDiagnoseMisCode(Option(v.familiarDiagnoseMisCode).getOrElse(""))
          data.setFamiliarDiagnoseName(Option(v.familiarDiagnoseName).getOrElse(""))
          data.setItemIndexMisCode(Option(v.itemIndexMisCode).getOrElse(""))
          data.setContent(Option(v.content).getOrElse(""))
        }
        .flatMap(runTransformers(_, transformers))

    healthRdd.keyBy(v => (v.examUser, v.examUserBirth))
      .aggregateByKey(List.empty[HealthData])(_ ++ List(_), _ ++ _)
      .map {
        case (_, list) =>
          val diagnoses = list.map(info => {
            Diagnose(
              info.scrq,
              info.checkItemMisCode,
              info.familiarDiagnoseMisCode,
              info.familiarDiagnoseName,
              info.itemIndexMisCode,
              info.content
            )
          })
          PersonInfo(
            list.last.examUser,
            list.last.examUserSex,
            list.last.examUserBirth,
            diagnoses
          )
      }
      .map(v => write(v))
      .repartition(2)
      .saveAsTextFile(output)
  }
}
