package com.ikang.ai.resource.flow.transformer.xueya

import com.ikang.ai.resource.flow.business.xueya.XueYaTags
import com.ikang.ai.resource.flow.transformer.Transformer

class XueYaTagsFilterTransformer extends Transformer[XueYaTags]("XueYaTagsFilterTransformer") {
  override def transform(value: XueYaTags): Option[XueYaTags] = {
    try {
      val tags = value.tags.filter(v =>
        if (v._2.equals("主动放弃") ||
          v._2.contains("自动放弃") ||
          v._2.equals("自述") ||
          v._2.equals("延期") ||
          v._2.equals("放弃") ||
          v._2.equals("未检") ||
          v._2.contains("---") ||
          v._2.equals("-.-") ||
          v._2.equals("严重乳糜血") ||
          v._2.equals("重度乳糜血") ||
          v._2.contains(">") ||
          v._2.contains("<") ||
          v._2.equals("") ||
          v._2.contains("严重"))
          false
        else
          true
      )
      value.tags = tags
    } catch {
      case _: Exception => logger.error(s"XueYaTagsFilterTransformer failed, data is: $XueYaTags")
    }
    Option(value)
  }

  override def check(value: XueYaTags): Boolean = {
    true
  }
}
