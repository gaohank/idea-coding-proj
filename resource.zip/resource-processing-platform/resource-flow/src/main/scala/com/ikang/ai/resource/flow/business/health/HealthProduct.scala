package com.ikang.ai.resource.flow.business.health

import java.util.Properties

import org.apache.kafka.clients.producer.{KafkaProducer, ProducerRecord}
import org.apache.spark.{SparkConf, SparkContext}

object HealthProduct {
  def main(args: Array[String]): Unit = {
    require(args.length == 3, "need input, server, topic")
    val Array(input, server, topic) = args
    val conf   = new SparkConf().setAppName(this.getClass.getSimpleName).setIfMissing("spark.master", "local")
    val sc     = new SparkContext(conf)
    val sources = sc.textFile(input).collect()

    writeToKafkaTopic(sources,server,topic)
  }

  def writeToKafkaTopic(lines: Array[String], kafkaServer: String, kafkaTopic: String): Unit ={
    val props = new Properties()
    props.put("bootstrap.servers", kafkaServer)
    props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer")
    props.put("value.serializer", "org.apache.kafka.common.serialization.StringSerializer")

    val producer = new KafkaProducer[String, String](props)
    for (line <- lines) {
      val record = new ProducerRecord(kafkaTopic, "health_data", line)
      producer.send(record)
    }
    producer.close()
  }
}
