package com.ikang.ai.resource.flow.business.health

import java.nio.charset.StandardCharsets

import com.google.common.io.Resources
import org.apache.spark.SparkConf
import org.apache.spark.sql.SparkSession

object Health2ES {
  def main(args: Array[String]): Unit = {
    require(args.length == 2, "need input, index")
    val Array(input, index) = args
    val conf = new SparkConf().setAppName(this.getClass.getSimpleName).setIfMissing("spark.master", "local[2]")
    val spark = SparkSession.builder().config(conf).getOrCreate()
    val jsonRdd = spark.sparkContext.textFile(input)

    val healthMapping = Resources.toString(
      Resources.getResource(getClass, "/es/health_mapping.json"),
      StandardCharsets.UTF_8
    )

    // 将数据存入ES中
    EsClient.writeIndex(index, jsonRdd, Some(healthMapping))

    System.exit(0)
  }
}
