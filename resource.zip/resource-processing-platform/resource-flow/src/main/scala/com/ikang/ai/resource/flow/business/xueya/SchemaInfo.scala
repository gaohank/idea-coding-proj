package com.ikang.ai.resource.flow.business.xueya

case class XueYaInfo(num: String, id: String, info: String)
case class XueYaTags(id: String, var tags: Map[String, String])
case class XueYaRes(id: String, tags: Map[String, Double])

class SchemaInfo {}
