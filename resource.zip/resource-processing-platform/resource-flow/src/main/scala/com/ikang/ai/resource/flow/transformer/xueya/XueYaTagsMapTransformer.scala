package com.ikang.ai.resource.flow.transformer.xueya

import com.ikang.ai.resource.flow.business.xueya.XueYaTags
import com.ikang.ai.resource.flow.transformer.Transformer

import scala.collection.JavaConversions._

class XueYaTagsMapTransformer extends Transformer[XueYaTags](name = "XueYaTagsMapTransformer") {
  override def transform(value: XueYaTags): Option[XueYaTags] = {
    // 将血压的部分属性映射为0，1
    try {
      if (value.tags.nonEmpty) {
        val tags = asJavaIterable(value.tags).map(v =>
          (v._1, v._1 match {
            case "尿酮体" | "尿胆红素" | "尿隐血" | "尿蛋白质" | "尿糖" => if (v._2 == "阴性") "1" else "0"
            case "家族史" => if (v._2 == "无") "1" else "0"
            case "心音" => if (v._2 == "正常") "1" else "0"
            // TODO: 问题有多个
            case "前列腺" => if (v._2 == "未见明显异常") "1" else "0"
            case "心电图" => if (v._2.contains("正常")) "1" else "0"
            case _ => if (v._2.contains(" ")) v._2.split(" ")(0) else v._2
          })
        ).toMap
        value.tags = tags
      }
    } catch {
      case _: Exception => logger.error(s"XueYaTagsMapTransformer failed, data is: $XueYaTags")
    }
    Option(value)
  }

  override def check(value: XueYaTags): Boolean = {
    true
  }
}
