package com.ikang.ai.resource.flow.transformer

import org.slf4j.{Logger, LoggerFactory}

abstract class Transformer[T](name: String) extends Serializable {
  val logger: Logger = LoggerFactory.getLogger(name)
  def transform(value: T): Option[T]
  def check(value: T): Boolean
}
