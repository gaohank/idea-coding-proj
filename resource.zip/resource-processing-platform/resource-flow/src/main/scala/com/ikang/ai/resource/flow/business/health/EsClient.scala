package com.ikang.ai.resource.flow.business.health

import java.net.InetAddress

import com.typesafe.config.{Config, ConfigFactory}
import org.apache.http.HttpHost
import org.apache.spark.rdd.RDD
import org.elasticsearch.ElasticsearchException
import org.elasticsearch.action.admin.indices.create.CreateIndexRequest
import org.elasticsearch.action.admin.indices.delete.DeleteIndexRequest
import org.elasticsearch.client.{RequestOptions, RestClient, RestHighLevelClient}
import org.elasticsearch.common.xcontent.XContentType
import org.elasticsearch.rest.RestStatus
import org.elasticsearch.spark.rdd.EsSpark
import org.slf4j.{Logger, LoggerFactory}

object EsClient {
  private val logger: Logger = LoggerFactory.getLogger("EsClient")
  val config: Config = ConfigFactory.load()
  private val nodes: String = config.getString("es.nodes")
  private val port: Int = config.getInt("es.port")
  val sparkOptions: Map[String, String] = Map("es.port" -> port.toString, "es.nodes" -> nodes)

  def writeIndex(index: String,
                 rdd: RDD[String],
                 mapping: Option[String] = None,
                 options: Option[Map[String, String]] = None,
                 overWrite: Boolean = true): Unit = {
    val additionalEsOptions = if (options.isEmpty) Map("es.index.auto.create" -> "true") else options.get
    if (overWrite) {
      logger.info(s"ES: delete $index")
      deleteIndex(index)
      logger.info(s"ES: create $index")
      createIndex(index, mapping)
    }
    logger.info(s"ES: saveJsonToEs to $index")
    EsSpark.saveJsonToEs(rdd, index, sparkOptions ++ additionalEsOptions)
    logger.info(s"ES: finished write RDD to $index")
  }

  def createIndex(indexType: String, mapping: Option[String]): Unit = {
    lazy val client = new RestHighLevelClient(RestClient.builder(new HttpHost(InetAddress.getByName(nodes), port)))
    val index   = indexType.split("/")(0)
    val request = new CreateIndexRequest(index)
    if (mapping.nonEmpty) {
      request.mapping(indexType.split("/")(1), mapping.get, XContentType.JSON)
    }
    import org.elasticsearch.client.RequestOptions
    val createIndexResponse = client.indices.create(request, RequestOptions.DEFAULT)
    logger.info(
      s"index: $index acknowledged = ${createIndexResponse.isAcknowledged}, shards = ${createIndexResponse.isShardsAcknowledged}"
    )
  }

  def deleteIndex(s: String): Unit = {
    lazy val client = new RestHighLevelClient(RestClient.builder(new HttpHost(InetAddress.getByName(nodes), port)))
    val index = s.split("/")(0)
    try {
      val request = new DeleteIndexRequest(index)
      client.indices().delete(request, RequestOptions.DEFAULT)
    } catch {
      case e: ElasticsearchException =>
        if (e.status() == RestStatus.NOT_FOUND) {
        }
    }
  }
}
