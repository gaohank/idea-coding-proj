package com.ikang.ai.resource.flow.transformer.health

import com.ikang.ai.resource.flow.HealthData
import com.ikang.ai.resource.flow.transformer.Transformer

class HealthFieldTransformer extends Transformer[HealthData]("HealthFieldTransformer"){
  override def transform(value: HealthData): Option[HealthData] = {
    HealthData._Fields.values().foreach(f => {
      if (value.getFieldValue(f) == "NULL")
        value.setFieldValue(f, "")
    })
    Option(value)
  }

  override def check(value: HealthData): Boolean = true
}
