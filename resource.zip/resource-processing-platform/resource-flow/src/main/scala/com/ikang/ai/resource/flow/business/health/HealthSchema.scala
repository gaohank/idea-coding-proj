package com.ikang.ai.resource.flow.business.health

case class HealthInfo(
                       workNo: String,
                       scrq: String, // 生成日期
                       examUser: String, // 体检人姓名
                       examUserSex: String, // 体检人性别
                       examUserBirth: String, // 体检人生日
                       checkItemMisCode: String, // 项目MIS码
                       familiarDiagnoseMisCode: String, // 诊断MIS码
                       familiarDiagnoseName: String, // 诊断名称
                       itemIndexMisCode: String, // 指标MIS码
                       content: String // 诊断描述
                     )

// 体检情况
case class Diagnose(
                     scrq: String, // 生成日期
                     checkItemMisCode: String, // 项目MIS码
                     familiarDiagnoseMisCode: String, // 诊断MIS码
                     familiarDiagnoseName: String, // 诊断名称
                     itemIndexMisCode: String, // 指标MIS码
                     content: String // 诊断描述
                   )

case class PersonInfo(
                       examUser: String, // 体检人名称
                       examUserSex: String, // 体检人性别
                       examUserBirth: String, // 体检人生日
                       diagnoses: List[Diagnose] // 历次体检情况
                     )

class HealthSchema {}
