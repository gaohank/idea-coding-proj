package com.ikang.ai.resource.flow.transformer.xueya

import com.ikang.ai.resource.flow.business.xueya.XueYaTags
import com.ikang.ai.resource.flow.transformer.Transformer

class XueYaTagsExtractTransformer extends Transformer[XueYaTags]("XueYaTagsSymbolTramsformer") {
  override def transform(value: XueYaTags): Option[XueYaTags] = {
    // 12.51 (乳糜血)
    // 11.06乳糜血
    // 客户自述：83.0
    val pattern = "\\(.*\\)|（.*）".r
    val pattern1 = "\\W+$".r
    val tags = value.tags
      .map(v => (v._1, pattern.replaceFirstIn(v._2, "").trim))
      .map(v => (v._1, pattern1.replaceFirstIn(v._2, "").trim))
      .map(v => (v._1, v._2.replaceAll("客户自述：", "")))
    value.tags = tags
    Option(value)
  }

  override def check(value: XueYaTags): Boolean = {
    true
  }
}
