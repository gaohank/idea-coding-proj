package com.ikang.ai.resource.flow.business.xueya

import java.io.StringReader

import com.ikang.ai.resource.flow.{getTransformers, runTransformers}
import com.opencsv.CSVReader
import org.apache.spark.{SparkConf, SparkContext}
import org.slf4j.{Logger, LoggerFactory}

import scala.collection.JavaConversions._

object ResourceNormalize {
  private val logger: Logger = LoggerFactory.getLogger("ResourceNormalize")

  def main(args: Array[String]): Unit = {
    require(args.length == 2, "input, output")
    val conf   = new SparkConf().setAppName(this.getClass.getSimpleName).setIfMissing("spark.master", "local")
    val sc     = new SparkContext(conf)
    val Array(input, output) = args
    val csvRdd = sc.wholeTextFiles(input)

    val xueYaInfoRdd = csvRdd.flatMap {
      case (_, v) =>
        val reader = new CSVReader(new StringReader(v))
        reader.readAll().map(v => XueYaInfo(v(0), v(1), v(2)))
    }

    // 加载transformer
    val transformers = getTransformers[XueYaTags]("transformer/xueya-transformer.conf")

    val xueYaResRdd = xueYaInfoRdd
      .map(v => {
        val map = v.info.split(",").map(v => {
          val tup = v.split("=")
          if (tup.size == 1) {
            (tup(0), "")
          } else {
            (tup(0), tup(1).trim)
          }
        }).toMap
        XueYaTags(v.id, map)
      })
      .flatMap(runTransformers(_, transformers))
      .map(v => {
        try {
          XueYaRes(v.id, v.tags.map(tag => (tag._1, tag._2.toDouble)))
        } catch {
          case _: Exception =>
            try {
              XueYaRes(v.id, v.tags.map(tag => (tag._1, tag._2.toInt.toDouble)))
            } catch {
              case _: Exception =>
                logger.error(s"XueYaTags -> XueYaRes failed, data is: $v")
                XueYaRes(v.id, Map())
            }
        }
      })
        .filter(_.tags.nonEmpty)

    println(xueYaResRdd.count)
    xueYaResRdd.saveAsTextFile(output)
  }
}
