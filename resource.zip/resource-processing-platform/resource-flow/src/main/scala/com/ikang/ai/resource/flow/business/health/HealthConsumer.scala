package com.ikang.ai.resource.flow.business.health

import java.io.StringReader
import java.net.InetAddress
import java.util
import java.util.Properties

import com.ikang.ai.resource.flow.{HealthData, getTransformers, runTransformers}
import com.opencsv.CSVReader
import com.typesafe.config.{Config, ConfigFactory}
import org.apache.flink.api.common.functions.{AggregateFunction, FlatMapFunction, RuntimeContext}
import org.apache.flink.api.common.serialization.SimpleStringSchema
import org.apache.flink.streaming.api.scala._
import org.apache.flink.streaming.api.windowing.assigners.ProcessingTimeSessionWindows
import org.apache.flink.streaming.api.windowing.time.Time
import org.apache.flink.streaming.api.{CheckpointingMode, TimeCharacteristic}
import org.apache.flink.streaming.connectors.elasticsearch.{ElasticsearchSinkFunction, RequestIndexer}
import org.apache.flink.streaming.connectors.elasticsearch6.ElasticsearchSink
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer09
import org.apache.flink.util.Collector
import org.apache.http.HttpHost
import org.elasticsearch.action.index.IndexRequest
import org.elasticsearch.client.Requests
import org.elasticsearch.common.xcontent.XContentType
import org.json4s.jackson.Serialization
import org.json4s.jackson.Serialization._
import org.json4s.{Formats, NoTypeHints}

object HealthConsumer {
  implicit val formats: AnyRef with Formats = Serialization.formats(NoTypeHints)
  val config: Config = ConfigFactory.load()

  def main(args: Array[String]): Unit = {
    require(args.length == 2, "need topic, index")
    val Array(topic, index) = args
    val props = new Properties()
    props.put("group.id", config.getString("kafka.group.id"))
    props.put("bootstrap.servers", config.getString("kafka.bootstrap.servers"))
    props.setProperty("zookeeper.connect", config.getString("kafka.zookeeper.connect"))
    props.put("auto.commit.enable", config.getString("kafka.auto.commit.enable"))
    props.put("auto.commit.interval.ms", config.getString("kafka.auto.commit.interval.ms"))
    props.put("key.deserializer", config.getString("kafka.key.deserializer"))
    props.put("value.deserializer", config.getString("kafka.value.deserializer"))

    val env = StreamExecutionEnvironment.getExecutionEnvironment
    env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime)
    env.enableCheckpointing(1000)
    env.getCheckpointConfig.setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE)

    val transaction = env.addSource(new FlinkKafkaConsumer09[String](topic, new SimpleStringSchema(), props))

    val transformers = getTransformers[HealthData]("transformer/health-transformer.conf")

    val healthData = transaction
      .flatMap(new FlatMapFunction[String, HealthInfo] {
        override def flatMap(t: String, collector: Collector[HealthInfo]): Unit = {
          val reader = new CSVReader(new StringReader(t))
          val strings = reader.readNext()
          collector.collect(HealthInfo(strings(0), strings(1), strings(2), strings(3), strings(4), strings(5), strings(6), strings(7), strings(8), strings(9)))
        }
      })
      .map { v =>
        val data = new HealthData()
        data.setWorkNo(Option(v.workNo).getOrElse(""))
        data.setScrq(Option(v.scrq).getOrElse(""))
        data.setExamUser(Option(v.examUser).getOrElse(""))
        data.setExamUserSex(Option(v.examUserSex).getOrElse(""))
        data.setExamUserBirth(Option(v.examUserBirth).getOrElse(""))
        data.setCheckItemMisCode(Option(v.checkItemMisCode).getOrElse(""))
        data.setFamiliarDiagnoseMisCode(Option(v.familiarDiagnoseMisCode).getOrElse(""))
        data.setFamiliarDiagnoseName(Option(v.familiarDiagnoseName).getOrElse(""))
        data.setItemIndexMisCode(Option(v.itemIndexMisCode).getOrElse(""))
        data.setContent(Option(v.content).getOrElse(""))
      }
      .flatMap(runTransformers(_, transformers))

    // 通过先映射成PersonInfo，再reduce会更优雅
    val personInfo = healthData.keyBy(v => (v.examUser, v.examUserBirth))
      .window(ProcessingTimeSessionWindows.withGap(Time.seconds(5)))
      .aggregate(new AggregateFunction[HealthData, PersonInfo, PersonInfo] {
        override def createAccumulator(): PersonInfo = {
          PersonInfo("", "", "", List.empty)
        }

        override def add(in: HealthData, acc: PersonInfo): PersonInfo = {
          PersonInfo(in.examUser, in.examUserSex, in.examUserBirth, acc.diagnoses ++
            List(Diagnose(in.scrq, in.checkItemMisCode, in.familiarDiagnoseMisCode, in.familiarDiagnoseName, in.itemIndexMisCode, in.content)))
        }

        override def getResult(acc: PersonInfo): PersonInfo = {
          acc
        }

        override def merge(acc: PersonInfo, acc1: PersonInfo): PersonInfo = {
          PersonInfo(acc.examUser, acc.examUserSex, acc.examUserBirth, acc.diagnoses ++ acc1.diagnoses)
        }
      })

    val transportAddress = new util.ArrayList[HttpHost]()
    transportAddress.add(new HttpHost(InetAddress.getByName(config.getString("es.nodes")), config.getInt("es.port")))

    val esSink = new ElasticsearchSink.Builder[String](
      transportAddress,
      new ElasticsearchSinkFunction[String] {
        def createIndexRequest(element: String): IndexRequest = {
          Requests.indexRequest()
            .index(index.split("/")(0))
            .`type`(index.split("/")(1))
            .source(element, XContentType.JSON)
        }

        override def process(t: String, runtimeContext: RuntimeContext, requestIndexer: RequestIndexer): Unit = {
          requestIndexer.add(createIndexRequest(t))
        }
      }
    )
    personInfo.map(write(_)).addSink(esSink.build())

    env.execute()
  }
}
