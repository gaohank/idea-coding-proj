package com.ikang.ai.resource.flow.transformer.xueya

import org.scalatest.FunSuite

class XueYaTagsSymbolTramsformerTest extends FunSuite {

  test("testTransform") {
    val name = "12.51 (乳糜血)"
    val pattern = "\\(.*\\)|（.*）".r
    assert("12.51" == pattern.replaceFirstIn(name, "").trim)

    val name1 = " 11.06乳糜血"
    val pattern1 = "^\\d+.\\d+|^\\d+".r
    assert("11.06" == pattern1.findFirstIn(name1.trim).get)

    val name2 = " 11.06乳糜血  "
    val pattern2 = "\\W+$".r
    assert("11.06" == pattern2.replaceFirstIn(name2, "").trim)
  }
}
