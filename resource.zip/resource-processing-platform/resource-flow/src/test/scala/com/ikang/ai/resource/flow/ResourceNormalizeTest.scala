package com.ikang.ai.resource.flow

import org.scalatest.FunSuite

class ResourceNormalizeTest extends FunSuite {
  test("num test demo") {
    println("１６７".toInt.toDouble)
    println(" ５５".trim.toInt)
  }
}
