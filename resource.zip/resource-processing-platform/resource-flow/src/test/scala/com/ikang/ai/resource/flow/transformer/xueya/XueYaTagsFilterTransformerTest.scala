package com.ikang.ai.resource.flow.transformer.xueya

import com.ikang.ai.resource.flow.business.xueya.XueYaTags
import org.scalatest.FunSuite

class XueYaTagsFilterTransformerTest extends FunSuite {
  test("transform") {
    val tags = Map("1" -> "主动放弃", "2" -> "自述", "3" -> "123")
    val value = XueYaTags("1", tags)
    val transformer = new XueYaTagsFilterTransformer
    val maybeTags = transformer.transform(value)
    assert(maybeTags.get.tags == Map("3" -> "123"))
  }
}
