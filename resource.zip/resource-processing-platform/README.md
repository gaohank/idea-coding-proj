# 项目名: resource-processing-platform

## 内容模块包括
| 模块     | 功能 |
|----------|------|
|resource-crawler|爬取数据并dump|
|resource-flow|数据流处理，包括清洗、融合、校验、保存|
|resource-controller|数据运营，对运营表中的数据进行更新、修改|
|resource-service|数据服务，提供上下线，下线回捞，上传下载等服务|
|resource-api|提供内部访问接口|

## 日志记录
- 日志均记录在项目根目录的各个子项目路径下

## 编译部署
- 编译项目
    - mvn clean compile
- 将项目编译到本地仓库
    - mvn -pl resource-crawler,resource-flow install
- 打包
    - mvn package
    - mvn clean package
    - mvn -U package        // 强制让maven检查依赖更新
- 插件
    - maven-assembly-plugin
    - maven-shade-plugin
    - maven-compiler-plugin
    - maven-jar-plugin
    - maven-dependency-plugin
- 部署
    - 通过指令的方式运行服务程序，spark部署在

## 测试
> 单元测试必须执行，必须全部通过才能上线

## pom版本
> 测试环境下使用version-SNAPSHOT，正式环境下使用version即可